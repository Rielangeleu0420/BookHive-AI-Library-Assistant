<?php
require_once 'functions.php';

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Get user info BEFORE destroying session
$userId = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['username'] ?? 'Unknown';

// Log the logout action only if we have a valid user_id
if ($userId > 0) {
    // Use null for book_id instead of user_id, and fix the description
    logAudit($userId, 'logout', null, "User {$username} logged out successfully");
} else {
    // If no valid user ID, log to error log but don't try to insert audit log
    error_log("Logout attempted without valid user ID for username: {$username}");
}

// Unset all of the session variables
$_SESSION = array();

// If it's desired to kill the session, also delete the session cookie.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: login.php");
exit();
?>