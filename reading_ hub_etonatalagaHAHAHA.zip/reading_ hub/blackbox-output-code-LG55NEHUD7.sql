-- =============================================
-- BookHive Database Setup Script
-- Database: reading_hub_db
-- Based on ERD and PHP code from the project
-- =============================================

-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS reading_hub_db;
USE reading_hub_db;

-- Drop tables in reverse order to avoid foreign key issues (if re-running)
DROP TABLE IF EXISTS recommendations;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS penalties;
DROP TABLE IF EXISTS loans;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS genres;
DROP TABLE IF EXISTS authors;
DROP TABLE IF EXISTS users;

-- =============================================
-- Table: users
-- Unified table for students and librarians (role-based)
-- =============================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('student', 'librarian') NOT NULL DEFAULT 'student',
    full_name VARCHAR(100) NOT NULL,
    lrn VARCHAR(12) UNIQUE,  -- Learner Reference Number (students only)
    year_level VARCHAR(20),  -- e.g., 'Grade 12' (students only)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Indexes for users
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- =============================================
-- Table: authors
-- =============================================
CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    author_name VARCHAR(100) NOT NULL,
    biography TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for authors
CREATE INDEX idx_authors_name ON authors(author_name);

-- =============================================
-- Table: genres
-- =============================================
CREATE TABLE genres (
    genre_id INT AUTO_INCREMENT PRIMARY KEY,
    genre_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Index for genres
CREATE INDEX idx_genres_name ON genres(genre_name);

-- =============================================
-- Table: books
-- =============================================
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author_id INT NOT NULL,
    genre_id INT NOT NULL,
    year_level VARCHAR(20),  -- e.g., 'K', 'Grade 1'
    illustrator VARCHAR(100),
    quantity_total INT NOT NULL DEFAULT 1 CHECK (quantity_total >= 1),
    quantity_available INT NOT NULL DEFAULT 1 CHECK (quantity_available >= 0),
    date_added DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES authors(author_id) ON DELETE RESTRICT,
    FOREIGN KEY (genre_id) REFERENCES genres(genre_id) ON DELETE RESTRICT
);

-- Indexes for books
CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_books_author ON books(author_id);
CREATE INDEX idx_books_genre ON books(genre_id);
CREATE INDEX idx_books_available ON books(quantity_available);

-- =============================================
-- Table: loans
-- =============================================
CREATE TABLE loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    extended_due_date DATE,
    due_date DATE NOT NULL,
    return_date DATE,
    status ENUM('borrowed', 'returned', 'overdue') NOT NULL DEFAULT 'borrowed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE RESTRICT
    -- Note: penalty_id FK is optional; penalties table references loan_id instead
);

-- Indexes for loans
CREATE INDEX idx_loans_student ON loans(student_id);
CREATE INDEX idx_loans_book ON loans(book_id);
CREATE INDEX idx_loans_status ON loans(status);
CREATE INDEX idx_loans_due_date ON loans(due_date);

-- =============================================
-- Table: penalties
-- =============================================
CREATE TABLE penalties (
    penalty_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    student_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (amount >= 0),
    status ENUM('pending', 'paid', 'waived') NOT NULL DEFAULT 'pending',
    date_assessed DATE NOT NULL,
    date_paid DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes for penalties
CREATE INDEX idx_penalties_loan ON penalties(loan_id);
CREATE INDEX idx_penalties_student ON penalties(student_id);
CREATE INDEX idx_penalties_status ON penalties(status);

-- =============================================
-- Table: audit_logs
-- =============================================
CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action_type VARCHAR(50) NOT NULL,  -- e.g., 'login', 'borrow_book', 'add_book'
    target_id INT,  -- e.g., book_id or loan_id
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes for audit_logs
CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_action ON audit_logs(action_type);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp);

-- =============================================
-- Optional Tables (from ERD, not heavily used in code but included for future)
-- =============================================

-- Table: notifications
CREATE TABLE notifications (
    notif_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    librarian_id INT,
    type VARCHAR(50) NOT NULL,  -- e.g., 'due', 'overdue', 'new_arrival'
    message TEXT NOT NULL,
    date_sent TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('unread', 'read') DEFAULT 'unread',
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (librarian_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes
CREATE INDEX idx_notif_student ON notifications(student_id);
CREATE INDEX idx_notif_librarian ON notifications(librarian_id);
CREATE INDEX idx_notif_type ON notifications(type);

-- Table: recommendations
CREATE TABLE recommendations (
    rec_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    book_id INT NOT NULL,
    availability_status ENUM('available', 'unavailable') DEFAULT 'available',
    recommended_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    suggested_source VARCHAR(100),  -- e.g., 'AI recommendation', 'external bookstore'
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE
);

-- Indexes
CREATE INDEX idx_rec_student ON recommendations(student_id);
CREATE INDEX idx_rec_book ON recommendations(book_id);

-- Table: reports
CREATE TABLE reports (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    librarian_id INT NOT NULL,
    report_type VARCHAR(50) NOT NULL,  -- e.g., 'borrowing_summary', 'overdue_report'
    date_generated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY (librarian_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Indexes
CREATE INDEX idx_reports_librarian ON reports(librarian_id);
CREATE INDEX idx_reports_type ON reports(report_type);

-- =============================================
-- Sample Data Insertion
-- =============================================

-- Insert sample genres
INSERT INTO genres (genre_name, description) VALUES
('Fiction', 'Fictional stories and novels'),
('Non-Fiction', 'Real-world facts and biographies'),
('Science', 'Books on scientific topics'),
('Mathematics', 'Math-related books'),
('Computer Science', 'Programming and IT books');

-- Insert sample authors
INSERT INTO authors (author_name, biography) VALUES
('Dr. Alex Kumar', 'Expert in machine learning and AI'),
('Maria Rodriguez', 'Renowned engineer and author'),
('Robert Johnson', 'Physics professor and writer'),
('Jane Austen', 'Classic fiction author'),
('Stephen Hawking', 'Theoretical physicist');

-- Insert sample books
INSERT INTO books (title, author_id, genre_id, year_level, illustrator, quantity_total, quantity_available, date_added) VALUES
('Machine Learning Fundamentals', 1, 5, 'Grade 12', NULL, 3, 2, '2024-01-15'),
('Digital Signal Processing', 2, 4, 'Grade 11', NULL, 2, 1, '2024-02-01'),
('Modern Physics', 3, 3, 'Grade 10', NULL, 1, 0, '2024-03-10'),
('Pride and Prejudice', 4, 1, 'Grade 9', NULL, 5, 4, '2023-12-01'),
('A Brief History of Time', 5, 2, 'Grade 12', NULL, 4, 3, '2024-01-20');

-- Insert sample users (demo credentials from login.php)
-- Passwords are hashed with 'password' using password_hash (PHP equivalent: password_hash('password', PASSWORD_DEFAULT))
INSERT INTO users (username, password_hash, email, role, full_name, lrn, year_level) VALUES
-- Student demo
('studentuser', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student@example.com', 'student', 'John Student Doe', '123456789012', 'Grade 12'),
-- Librarian demo
('librarianuser', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'librarian@example.com', 'librarian', 'Jane Librarian Smith', NULL, NULL);

-- Note: The hashed password above is for 'password'. In production, use PHP to hash real passwords.
-- If you need to verify: In PHP, use password_verify('password', '$2y$10$...');

-- Insert sample loans (for studentuser, user_id=1)
INSERT INTO loans (student_id, book_id, borrow_date, due_date, status) VALUES
(1, 1, '2024-03-01', '2024-03-15', 'borrowed'),
(1, 2, '2024-03-10', '2024-03-20', 'overdue');  -- Overdue for demo

-- Insert sample penalties (for the overdue loan)
INSERT INTO penalties (loan_id, student_id, amount, status, date_assessed) VALUES
(2, 1, 200.00, 'pending', '2024-03-21');  -- ₱200 for overdue

-- Insert sample audit log
INSERT INTO audit_logs (user_id, action_type, target_id, details) VALUES
(1, 'login', 1, 'Student logged in successfully.');

-- =============================================
-- Verification Queries (Run these to check)
-- =============================================
-- SELECT * FROM users;
-- SELECT * FROM books JOIN authors ON books.author_id = authors.author_id;
-- SELECT * FROM loans JOIN users ON loans.student_id = users.user_id JOIN books ON loans.book_id = books.book_id;

-- Success message
SELECT 'Database setup complete! Tables created with sample data.' AS status;