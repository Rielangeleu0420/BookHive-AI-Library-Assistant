<?php
/**
 * BookHive Footer
 */
// Check if user is logged in and get their role
$current_role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
$showAIChat = isset($_SESSION['showAIChat']) ? $_SESSION['showAIChat'] : false;
?>
    </div> <!-- End of main-content -->

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <p>Donated by Mapúa University Information Technology Students</p>
            <div class="footer-decoration">
                <i data-lucide="heart" class="footer-icon"></i>
            </div>
        </div>
    </footer>

    <!-- AI Chat for Students -->
    <?php if ($current_role === 'student'): ?>
        <!-- AI Chatbot Button for Students -->
        <button class="ai-chat-fab" onclick="toggleAIChat()">
            <i data-lucide="message-circle"></i>
            <span>AI Assistant</span>
        </button>

        <!-- AI Chatbot Modal -->
        <div id="aiChatModal" class="ai-chat-modal" style="display: none;">
            <div class="ai-chat-content">
                <div class="ai-chat-header">
                    <div class="ai-chat-header-left">
                        <i data-lucide="bot" class="ai-chat-icon"></i>
                        <div class="ai-chat-title-section">
                            <span class="ai-chat-title">AI Library Assistant</span>
                            <span class="ai-chat-status">Online</span>
                        </div>
                    </div>
                    <button class="ai-chat-close-btn" onclick="toggleAIChat()">
                        <i data-lucide="x"></i>
                    </button>
                </div>
                
                <div class="ai-chat-description">
                    <p>Chat with your AI-powered library assistant to get book recommendations, check availability, manage loans, handle penalty payments, and find books at external sources when unavailable.</p>
                </div>
                
                <div id="aiChatBody" class="ai-chat-body">
                    <!-- Chat content will be loaded here via AJAX -->
                    <div class="ai-chat-loading">
                        <i data-lucide="loader-2" class="loading-icon"></i>
                        <span>Loading AI Assistant...</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- AI Chat JavaScript -->
        <script>
            let aiChatOpen = <?php echo $showAIChat ? 'true' : 'false'; ?>;
            const aiChatModal = document.getElementById('aiChatModal');
            const aiChatBody = document.getElementById('aiChatBody');

            function toggleAIChat() {
                aiChatOpen = !aiChatOpen;
                if (aiChatOpen) {
                    aiChatModal.style.display = 'flex';
                    loadAIChatContent();
                } else {
                    aiChatModal.style.display = 'none';
                }
            }

            async function loadAIChatContent() {
                try {
                    // Show loading state
                    aiChatBody.innerHTML = `
                        <div class="ai-chat-loading">
                            <i data-lucide="loader-2" class="loading-icon"></i>
                            <span>Loading AI Assistant...</span>
                        </div>
                    `;
                    lucide.createIcons();

                    const response = await fetch('AIChat.php');
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const html = await response.text();
                    aiChatBody.innerHTML = html;
                    
                    // Re-initialize Lucide icons after content is loaded
                    lucide.createIcons();
                    
                    // Scroll to bottom after loading
                    setTimeout(() => {
                        const messagesEndRef = document.querySelector('.ai-chat-messages-end');
                        if (messagesEndRef) {
                            messagesEndRef.scrollIntoView({ behavior: 'smooth' });
                        }
                    }, 100);
                    
                } catch (error) {
                    console.error("Failed to load AI Chat content:", error);
                    aiChatBody.innerHTML = `
                        <div class="ai-chat-error">
                            <i data-lucide="alert-circle" class="error-icon"></i>
                            <p>Error loading chat. Please try again.</p>
                            <button class="retry-btn" onclick="loadAIChatContent()">Retry</button>
                        </div>
                    `;
                    lucide.createIcons();
                }
            }

            // Close chat when clicking outside
            document.addEventListener('click', function(event) {
                const chatModal = document.getElementById('aiChatModal');
                const chatFab = document.querySelector('.ai-chat-fab');
                
                if (aiChatOpen && 
                    !chatModal.contains(event.target) && 
                    !chatFab.contains(event.target)) {
                    toggleAIChat();
                }
            });

            // Open AI Chat on page load if showAIChat is true
            document.addEventListener('DOMContentLoaded', function() {
                if (aiChatOpen) {
                    toggleAIChat();
                }
                
                // Initialize Lucide icons
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            });

            // Handle Escape key to close chat
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape' && aiChatOpen) {
                    toggleAIChat();
                }
            });
        </script>
    <?php endif; ?>


    <!-- Initialize Lucide Icons -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        });
    </script>
</body>
</html>