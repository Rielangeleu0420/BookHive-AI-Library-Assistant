# BookHive-AI-Library-Assistant
AI-powered library assistant with smart recommendations and secure inventory management system.
